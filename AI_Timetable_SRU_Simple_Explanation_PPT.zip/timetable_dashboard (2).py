import streamlit as st
import pandas as pd
import numpy as np
import os

# ==================================================
# 1. PAGE CONFIGURATION
# ==================================================

st.set_page_config(
    page_title="SR University Academic Portal",
    page_icon="🎓",
    layout="wide"
)

st.markdown("""
<style>
.stApp {
    background-color: #f1f5f9;
}
[data-testid="stSidebar"] {
    background-color: #173966;
}
[data-testid="stSidebar"] * {
    color: white !important;
}
[data-testid="stMetric"] {
    background: white;
    padding: 17px;
    border-radius: 12px;
    border: 1px solid #dce4ef;
}
h1, h2, h3 {
    color: #173966;
}
.stButton button {
    background-color: #173966;
    color: white;
    border-radius: 8px;
}
[data-testid="stHeader"] {
    background-color: white;
}
</style>
""", unsafe_allow_html=True)


# ==================================================
# 2. COLLEGE DATA
# ==================================================

departments = ["CSE", "ECE", "EEE", "MECH", "CIVIL"]

sections = [
    "CSE-A", "CSE-B",
    "ECE-A", "ECE-B",
    "EEE-A", "EEE-B",
    "MECH-A", "MECH-B",
    "CIVIL-A", "CIVIL-B"
]

days = [
    "Monday", "Tuesday", "Wednesday",
    "Thursday", "Friday"
]

periods = [
    "9-10 AM", "10-11 AM", "11-12 PM",
    "12-1 PM", "2-3 PM", "3-4 PM"
]

subjects = {
    "CSE": [
        "Python", "DBMS", "Java",
        "Mathematics", "Operating Systems", "Networks"
    ],
    "ECE": [
        "Digital Electronics", "Signals",
        "Microprocessors", "Mathematics",
        "Communication", "Circuits"
    ],
    "EEE": [
        "Electrical Machines", "Power Systems",
        "Control Systems", "Mathematics",
        "Circuits", "Measurements"
    ],
    "MECH": [
        "Thermodynamics", "Engineering Mechanics",
        "Fluid Mechanics", "Mathematics",
        "Manufacturing", "CAD"
    ],
    "CIVIL": [
        "Structural Engineering", "Surveying",
        "Concrete Technology", "Mathematics",
        "Geotechnical", "Fluid Mechanics"
    ]
}


# ==================================================
# 3. FACULTY DATA
# ==================================================

faculty_names = [
    "Ravi Kumar", "Priya Sharma", "Kiran Reddy",
    "Ananya Rao", "Rahul Verma", "Sneha Patel",
    "Arjun Mehta", "Divya Nair", "Suresh Babu",
    "Kavya Reddy",

    "Vijay Kumar", "Meena Sharma", "Akhil Reddy",
    "Pooja Rao", "Manoj Kumar", "Swathi Patel",
    "Harish Verma", "Nisha Reddy", "Deepak Singh",
    "Keerthi Nair",

    "Praveen Kumar", "Lakshmi Devi", "Sandeep Rao",
    "Anjali Gupta", "Ramesh Babu", "Bhavana Reddy",
    "Naveen Kumar", "Sravani Rao", "Tarun Sharma",
    "Madhavi Nair",

    "Karthik Reddy", "Shilpa Rao", "Gopal Krishna",
    "Neha Sharma", "Mahesh Kumar", "Aishwarya Patel",
    "Varun Mehta", "Haritha Reddy", "Rohit Singh",
    "Sowmya Nair",

    "Chandrika Rao", "Abhishek Kumar", "Swetha Reddy",
    "Nikhil Sharma", "Sunil Babu", "Monika Patel",
    "Sai Krishna", "Deepa Nair", "Anil Kumar",
    "Tejaswini Rao"
]

faculty_rows = []

for i in range(50):

    dept = departments[i // 10]

    faculty_rows.append({
        "Faculty ID": f"FAC{i+1:03}",
        "Faculty Name": faculty_names[i],
        "Department": dept,
        "Designation": (
            "Professor" if i % 3 == 0
            else "Assistant Professor"
        ),
        "Email": (
            faculty_names[i].lower().replace(" ", ".")
            + "@college.edu"
        )
    })

faculty_df = pd.DataFrame(faculty_rows)


# Faculty subject allocation

faculty_mapping = {}

for dept in departments:

    dept_faculty = faculty_df[
        faculty_df["Department"] == dept
    ]["Faculty Name"].tolist()

    for i, subject in enumerate(subjects[dept]):

        faculty_mapping[(dept, subject)] = dept_faculty[i]


# ==================================================
# 4. STUDENT DATA
# ==================================================

student_names = [
    "Aarav", "Aditya", "Akash", "Ananya", "Arjun",
    "Bhavana", "Charan", "Deepika", "Divya", "Harsha",
    "Kavya", "Kiran", "Krishna", "Lakshmi", "Manasa",
    "Meghana", "Naveen", "Nikhil", "Pooja", "Pranav",
    "Priya", "Rahul", "Rakesh", "Rohit", "Sai",
    "Sandeep", "Sneha", "Sowmya", "Sravani", "Swathi",
    "Tarun", "Tejaswi", "Varun", "Vijay", "Vishnu",
    "Abhinav", "Anjali", "Ashwin", "Bharath",
    "Chaitanya", "Dinesh", "Gowtham", "Harini",
    "Keerthi", "Mahesh", "Manoj", "Monika",
    "Neha", "Praveen", "Shreya"
]

surnames = [
    "Reddy", "Sharma", "Kumar", "Rao", "Patel",
    "Verma", "Nair", "Gupta", "Singh", "Naidu"
]

np.random.seed(42)

student_rows = []

for i in range(500):

    dept = departments[i // 100]
    section = sections[i // 50]

    name = (
        f"{np.random.choice(student_names)} "
        f"{np.random.choice(surnames)}"
    )

    student_rows.append({
        "Student ID": f"STU{i+1:04}",
        "Student Name": name,
        "Department": dept,
        "Section": section,
        "Year": "II Year",
        "Attendance": np.random.randint(75, 100)
    })

students_df = pd.DataFrame(student_rows)


# ==================================================
# 5. TIMETABLE GENERATION
# ==================================================

def create_timetable():

    timetable = []

    for dept in departments:

        dept_sections = [
            s for s in sections
            if s.startswith(dept)
        ]

        for day_index, day in enumerate(days):

            order = np.random.default_rng(
                100 + day_index
            ).permutation(6)

            for section_index, section in enumerate(dept_sections):

                assigned_order = np.roll(
                    order, section_index
                )

                for period_index, subject_index in enumerate(
                    assigned_order
                ):

                    subject = subjects[dept][subject_index]

                    faculty = faculty_mapping[
                        (dept, subject)
                    ]

                    timetable.append({
                        "Day": day,
                        "Day Order": day_index,
                        "Period": periods[period_index],
                        "Period Order": period_index,
                        "Department": dept,
                        "Section": section,
                        "Subject": subject,
                        "Faculty": faculty,
                        "Room": f"Room {101 + sections.index(section)}"
                    })

    return pd.DataFrame(timetable)


timetable_df = create_timetable()


# ==================================================
# 6. COMMON TIMETABLE FUNCTION
# ==================================================

def show_section_timetable(section):

    data = timetable_df[
        timetable_df["Section"] == section
    ]

    table = data.pivot(
        index="Day",
        columns="Period",
        values="Subject"
    )

    table = table.reindex(
        index=days,
        columns=periods
    )

    st.dataframe(
        table,
        use_container_width=True
    )

    st.write("Faculty and Classroom Details")

    st.dataframe(
        data[
            ["Day", "Period", "Subject", "Faculty", "Room"]
        ],
        use_container_width=True,
        hide_index=True
    )


# ==================================================
# 7. SIDEBAR - SR UNIVERSITY PORTAL
# ==================================================

st.sidebar.markdown(
    "<h2 style='text-align:center;'>🎓 SR UNIVERSITY</h2>",
    unsafe_allow_html=True
)

st.sidebar.markdown(
    "<p style='text-align:center;'>Academic Management Portal</p>",
    unsafe_allow_html=True
)

# Add official logo if available

if os.path.exists("sru_logo.png"):
    st.sidebar.image("sru_logo.png", width=180)

st.sidebar.divider()

menu = st.sidebar.radio(
    "PORTAL NAVIGATION",
    [
        "Dashboard",
        "Global Search",
        "Weekly Timetable",
        "Faculty Management",
        "Student Management",
        "Section Management",
        "Room Allocation",
        "Reports & Downloads"
    ]
)

st.sidebar.divider()

st.sidebar.success("System Status: Active")

st.sidebar.caption(
    "SR University | Academic Portal"
)


# ==================================================
# 8. PORTAL HEADER
# ==================================================

header1, header2 = st.columns([4, 1])

with header1:

    st.title("SR UNIVERSITY")

    st.subheader("Academic Management Portal")

    st.write(
        "College Timetable and Resource Management System"
    )

with header2:

    if os.path.exists("sru_logo.png"):
        st.image("sru_logo.png", width=120)
    else:
        st.markdown(
            "<h1 style='text-align:center;color:#173966;'>SR</h1>",
            unsafe_allow_html=True
        )

st.divider()


# ==================================================
# 9. DASHBOARD
# ==================================================

if menu == "Dashboard":

    st.subheader("📊 Admin Dashboard")

    c1, c2, c3, c4 = st.columns(4)

    c1.metric(
        "Total Students", len(students_df)
    )

    c2.metric(
        "Total Faculty", len(faculty_df)
    )

    c3.metric(
        "Total Sections", len(sections)
    )

    c4.metric(
        "Weekly Classes", len(timetable_df)
    )

    st.divider()

    st.subheader("🏢 Department Overview")

    left, right = st.columns(2)

    with left:

        st.write("Students by Department")

        st.bar_chart(
            students_df.groupby("Department").size()
        )

    with right:

        st.write("Faculty by Department")

        st.bar_chart(
            faculty_df.groupby("Department").size()
        )

    st.divider()

    st.subheader("📅 Daily Timetable")

    selected_day = st.selectbox(
        "Select Day", days
    )

    today = timetable_df[
        timetable_df["Day"] == selected_day
    ]

    st.dataframe(
        today[
            ["Section", "Period", "Subject", "Faculty", "Room"]
        ],
        use_container_width=True,
        hide_index=True
    )

    st.success(
        "All 300 weekly class periods have been generated."
    )


# ==================================================
# 10. GLOBAL SEARCH
# ==================================================

elif menu == "Global Search":

    st.subheader("🔍 Global Search")

    st.write(
        "Search for faculty, students, classrooms, "
        "sections, subjects and timetables."
    )

    search = st.text_input(
        "Search College Information",
        placeholder="Enter faculty name, student name, Room 101, CSE-A, Python..."
    ).strip()

    if search:

        q = search.lower()

        found = False

        # -------- FACULTY SEARCH --------

        faculty_result = faculty_df[
            faculty_df.astype(str).apply(
                lambda col: col.str.lower().str.contains(
                    q, na=False
                )
            ).any(axis=1)
        ]

        if not faculty_result.empty:

            found = True

            st.divider()
            st.subheader("👨‍🏫 Faculty Information")

            st.dataframe(
                faculty_result,
                use_container_width=True,
                hide_index=True
            )

            names = faculty_result[
                "Faculty Name"
            ].tolist()

            schedule = timetable_df[
                timetable_df["Faculty"].isin(names)
            ]

            st.write("Faculty Weekly Workload")

            workload = schedule.groupby(
                ["Faculty", "Subject"]
            ).size().reset_index(
                name="Weekly Periods"
            )

            st.dataframe(
                workload,
                use_container_width=True,
                hide_index=True
            )

            st.write("Complete Faculty Timetable")

            st.dataframe(
                schedule[
                    ["Day", "Period", "Subject",
                     "Section", "Room", "Faculty"]
                ],
                use_container_width=True,
                hide_index=True
            )

        # -------- STUDENT SEARCH --------

        student_result = students_df[
            students_df.astype(str).apply(
                lambda col: col.str.lower().str.contains(
                    q, na=False
                )
            ).any(axis=1)
        ]

        if not student_result.empty:

            found = True

            st.divider()
            st.subheader("👨‍🎓 Student Information")

            st.dataframe(
                student_result,
                use_container_width=True,
                hide_index=True
            )

            student_sections = (
                student_result["Section"].unique()
            )

            for section in student_sections:

                st.write(
                    f"Class Timetable: {section}"
                )

                show_section_timetable(section)

        # -------- ROOM SEARCH --------

        room_result = timetable_df[
            timetable_df["Room"].str.lower().str.contains(
                q, na=False
            )
        ]

        if not room_result.empty:

            found = True

            st.divider()
            st.subheader("🏢 Room Information")

            room_summary = room_result.groupby(
                "Room"
            ).agg(
                Total_Classes=("Subject", "count"),
                Sections=("Section", "nunique"),
                Faculty=("Faculty", "nunique")
            ).reset_index()

            st.write("Room Summary")

            st.dataframe(
                room_summary,
                use_container_width=True,
                hide_index=True
            )

            st.write("Complete Room Timetable")

            st.dataframe(
                room_result[
                    ["Day", "Period", "Section",
                     "Subject", "Faculty", "Room"]
                ],
                use_container_width=True,
                hide_index=True
            )

        # -------- SECTION SEARCH --------

        section_result = timetable_df[
            timetable_df["Section"].str.lower().str.contains(
                q, na=False
            )
        ]

        if not section_result.empty:

            found = True

            st.divider()
            st.subheader("🏫 Class / Section Information")

            for section in section_result[
                "Section"
            ].unique():

                st.markdown(f"### {section}")

                section_students = students_df[
                    students_df["Section"] == section
                ]

                st.metric(
                    "Total Students",
                    len(section_students)
                )

                st.write("Student List")

                st.dataframe(
                    section_students,
                    use_container_width=True,
                    hide_index=True
                )

                st.write("Weekly Class Timetable")

                show_section_timetable(section)

        # -------- SUBJECT SEARCH --------

        subject_result = timetable_df[
            timetable_df["Subject"].str.lower().str.contains(
                q, na=False
            )
        ]

        if not subject_result.empty:

            found = True

            st.divider()
            st.subheader("📚 Subject Information")

            st.dataframe(
                subject_result[
                    ["Department", "Section", "Day",
                     "Period", "Subject", "Faculty", "Room"]
                ],
                use_container_width=True,
                hide_index=True
            )

        if not found:

            st.warning(
                "No information found. Please try another search."
            )

    else:

        st.info(
            "Enter a faculty name, student name, "
            "room number, section or subject."
        )


# ==================================================
# 11. WEEKLY TIMETABLE
# ==================================================

elif menu == "Weekly Timetable":

    st.subheader("📅 Weekly Class Timetable")

    col1, col2 = st.columns(2)

    with col1:

        selected_dept = st.selectbox(
            "Select Department", departments
        )

    dept_sections = [
        s for s in sections
        if s.startswith(selected_dept)
    ]

    with col2:

        selected_section = st.selectbox(
            "Select Section", dept_sections
        )

    st.subheader(
        f"{selected_section} Weekly Timetable"
    )

    show_section_timetable(selected_section)


# ==================================================
# 12. FACULTY MANAGEMENT
# ==================================================

elif menu == "Faculty Management":

    st.subheader("👨‍🏫 Faculty Management")

    c1, c2 = st.columns(2)

    with c1:

        dept_filter = st.selectbox(
            "Department",
            ["All"] + departments
        )

    with c2:

        search = st.text_input(
            "Search Faculty Name"
        )

    filtered = faculty_df.copy()

    if dept_filter != "All":

        filtered = filtered[
            filtered["Department"] == dept_filter
        ]

    if search:

        filtered = filtered[
            filtered["Faculty Name"].str.contains(
                search, case=False, na=False
            )
        ]

    st.metric(
        "Faculty Members Displayed",
        len(filtered)
    )

    st.dataframe(
        filtered,
        use_container_width=True,
        hide_index=True
    )

    st.subheader("Faculty Weekly Workload")

    workload = timetable_df.groupby(
        "Faculty"
    ).size().reset_index(
        name="Weekly Periods"
    )

    st.dataframe(
        workload,
        use_container_width=True,
        hide_index=True
    )

    st.bar_chart(
        workload.set_index("Faculty")
    )


# ==================================================
# 13. STUDENT MANAGEMENT
# ==================================================

elif menu == "Student Management":

    st.subheader("👨‍🎓 Student Management")

    col1, col2 = st.columns(2)

    with col1:

        dept_filter = st.selectbox(
            "Department",
            ["All"] + departments
        )

    with col2:

        section_filter = st.selectbox(
            "Section",
            ["All"] + sections
        )

    filtered = students_df.copy()

    if dept_filter != "All":

        filtered = filtered[
            filtered["Department"] == dept_filter
        ]

    if section_filter != "All":

        filtered = filtered[
            filtered["Section"] == section_filter
        ]

    st.metric(
        "Total Students Displayed",
        len(filtered)
    )

    st.dataframe(
        filtered,
        use_container_width=True,
        hide_index=True
    )

    st.subheader("📈 Attendance Overview")

    if not filtered.empty:

        st.metric(
            "Average Attendance",
            f"{filtered['Attendance'].mean():.1f}%"
        )

        st.bar_chart(
            filtered.groupby("Section")["Attendance"].mean()
        )

    else:

        st.warning("No students found.")


# ==================================================
# 14. SECTION MANAGEMENT
# ==================================================

elif menu == "Section Management":

    st.subheader("🏫 Section Management")

    section_summary = students_df.groupby(
        ["Department", "Section"]
    ).agg(
        Total_Students=("Student ID", "count"),
        Average_Attendance=("Attendance", "mean")
    ).reset_index()

    section_summary["Average_Attendance"] = (
        section_summary["Average_Attendance"].round(1)
    )

    st.dataframe(
        section_summary,
        use_container_width=True,
        hide_index=True
    )

    st.subheader("Section-wise Student Strength")

    st.bar_chart(
        students_df.groupby("Section").size()
    )


# ==================================================
# 15. ROOM ALLOCATION
# ==================================================

elif menu == "Room Allocation":

    st.subheader("🏢 Classroom Allocation")

    room_summary = timetable_df.groupby(
        "Room"
    ).agg(
        Total_Classes=("Subject", "count"),
        Sections=("Section", "nunique"),
        Faculty=("Faculty", "nunique")
    ).reset_index()

    st.dataframe(
        room_summary,
        use_container_width=True,
        hide_index=True
    )

    st.subheader("Room Schedule")

    selected_room = st.selectbox(
        "Select Classroom",
        sorted(timetable_df["Room"].unique())
    )

    room_data = timetable_df[
        timetable_df["Room"] == selected_room
    ]

    st.dataframe(
        room_data[
            ["Day", "Period", "Section",
             "Subject", "Faculty"]
        ],
        use_container_width=True,
        hide_index=True
    )


# ==================================================
# 16. REPORTS AND DOWNLOADS
# ==================================================

elif menu == "Reports & Downloads":

    st.subheader("📥 College Reports & Downloads")

    st.write(
        "Download the generated academic management reports."
    )

    downloads = {
        "Complete Timetable": timetable_df,
        "Faculty Details": faculty_df,
        "Student Details": students_df
    }

    for name, df in downloads.items():

        csv = df.to_csv(
            index=False
        ).encode("utf-8")

        st.download_button(
            label=f"⬇️ Download {name}",
            data=csv,
            file_name=(
                name.lower().replace(" ", "_") + ".csv"
            ),
            mime="text/csv",
            key=name
        )

    st.divider()

    st.subheader("📊 Project Summary")

    summary = pd.DataFrame({
        "Category": [
            "Departments",
            "Faculty Members",
            "Students",
            "Sections",
            "Working Days",
            "Periods Per Day",
            "Total Weekly Periods"
        ],
        "Count": [
            5, 50, 500, 10, 5, 6,
            len(timetable_df)
        ]
    })

    st.table(summary)


# ==================================================
# 17. FOOTER
# ==================================================

st.divider()

st.markdown(
    """
    <div style="text-align:center; color:#64748b;">
        <h4>SR UNIVERSITY</h4>
        Academic Management Portal<br>
        College Timetable Preparation System<br>
        ©️ 2026 Academic Management Project
    </div>
    """,
    unsafe_allow_html=True
)
