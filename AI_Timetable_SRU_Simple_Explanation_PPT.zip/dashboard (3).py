import streamlit as st
import pandas as pd

# =====================================================
# 1. PAGE CONFIGURATION
# =====================================================

st.set_page_config(
    page_title="SR University Academic Portal",
    page_icon="🎓",
    layout="wide"
)

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]

SUBJECTS = [
    "Python", "DBMS", "Mathematics",
    "Java", "Operating Systems", "Computer Networks"
]

ROOMS = [f"Room {i}" for i in range(101, 121)]


# =====================================================
# 2. SESSION STATE
# =====================================================

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "username" not in st.session_state:
    st.session_state.username = ""

if "marks_df" not in st.session_state:
    st.session_state.marks_df = pd.DataFrame(
        columns=[
            "Student_ID", "Student_Name", "Section",
            "Subject", "Exam", "Marks"
        ]
    )


# =====================================================
# 3. HEADER AND CSV UPLOAD
# =====================================================

st.markdown(
    "<h1 style='text-align:center;'>🎓 SR UNIVERSITY</h1>",
    unsafe_allow_html=True
)

st.markdown(
    "<h3 style='text-align:center;'>Academic Management Portal</h3>",
    unsafe_allow_html=True
)

st.divider()

uploaded_file = st.file_uploader(
    "Upload Student and Faculty CSV File",
    type=["csv"],
    key="college_csv"
)

if uploaded_file is None:
    st.warning("Please upload your student and faculty CSV file.")
    st.info(
        "Your CSV should contain these columns: "
        "Role, Name, Department, Section, Year, Email"
    )
    st.stop()


# =====================================================
# 4. READ CSV DIRECTLY
# =====================================================

try:
    data = pd.read_csv(uploaded_file)

    # Remove extra spaces from column headings
    data.columns = data.columns.str.strip()

    required_columns = [
        "Role", "Name", "Department",
        "Section", "Year", "Email"
    ]

    missing_columns = [
        column for column in required_columns
        if column not in data.columns
    ]

    if missing_columns:
        st.error(
            "Your CSV is missing these columns: "
            + ", ".join(missing_columns)
        )
        st.stop()

    # Clean text values
    for column in required_columns:
        data[column] = data[column].fillna("").astype(str).str.strip()

    data["Role"] = data["Role"].str.lower()

    # Separate students and faculty
    students_df = data[
        data["Role"] == "student"
    ].copy()

    faculty_df = data[
        data["Role"] == "faculty"
    ].copy()

    students_df.rename(
        columns={"Name": "Student_Name"},
        inplace=True
    )

    faculty_df.rename(
        columns={"Name": "Faculty_Name"},
        inplace=True
    )

    # Generate internal IDs
    students_df["Student_ID"] = [
        f"STU{i+1:03d}" for i in range(len(students_df))
    ]

    faculty_df["Faculty_ID"] = [
        f"FAC{i+1:03d}" for i in range(len(faculty_df))
    ]

    students_df.reset_index(drop=True, inplace=True)
    faculty_df.reset_index(drop=True, inplace=True)

    if students_df.empty:
        st.error("No student records found in the CSV.")
        st.stop()

    if faculty_df.empty:
        st.error("No faculty records found in the CSV.")
        st.stop()

except Exception as error:
    st.error(f"Unable to read CSV: {error}")
    st.stop()


# =====================================================
# 5. GENERATE TIMETABLE
# =====================================================

sections = sorted(
    students_df["Section"].dropna().unique().tolist()
)

faculty_names = faculty_df["Faculty_Name"].tolist()

if not sections:
    st.error("No sections found in your CSV.")
    st.stop()

if not faculty_names:
    st.error("No faculty names found in your CSV.")
    st.stop()


def generate_timetable():

    records = []

    for day in DAYS:

        for section_index, section in enumerate(sections):

            for period in range(1, 7):

                faculty_index = (
                    section_index * 6 + period - 1
                ) % len(faculty_names)

                room_index = (
                    section_index * 6 + period - 1
                ) % len(ROOMS)

                records.append({
                    "Day": day,
                    "Period": period,
                    "Section": section,
                    "Subject": SUBJECTS[(period - 1) % len(SUBJECTS)],
                    "Faculty": faculty_names[faculty_index],
                    "Room": ROOMS[room_index]
                })

    return pd.DataFrame(records)


timetable_df = generate_timetable()


# =====================================================
# 6. LOGIN PAGE
# =====================================================

if not st.session_state.logged_in:

    st.subheader("🔐 Login to Continue")

    left, middle, right = st.columns([1, 2, 1])

    with middle:

        with st.form("login_form"):

            username = st.text_input("Username")

            password = st.text_input(
                "Password",
                type="password"
            )

            login_button = st.form_submit_button(
                "Login",
                use_container_width=True
            )

            if login_button:

                username = username.strip().lower()

                if username == "admin" and password == "admin123":

                    st.session_state.logged_in = True
                    st.session_state.username = "Admin"
                    st.rerun()

                elif username == "faculty" and password == "faculty123":

                    st.session_state.logged_in = True
                    st.session_state.username = "Faculty"
                    st.rerun()

                else:
                    st.error("Invalid username or password.")

        st.info("Admin: admin / admin123")
        st.info("Faculty: faculty / faculty123")

    st.stop()


# =====================================================
# 7. SIDEBAR
# =====================================================

st.sidebar.title("🎓 SR UNIVERSITY")

st.sidebar.caption("Academic Management Portal")

st.sidebar.success(
    "Logged in as: " + st.session_state.username
)

menu = st.sidebar.selectbox(
    "Select Dashboard",
    [
        "Dashboard",
        "Student Management",
        "Faculty Management",
        "Timetable Management",
        "Section Management",
        "Marks Allocation",
        "Room Allocation",
        "Reports & Downloads"
    ]
)

st.sidebar.divider()

if st.sidebar.button("🚪 Logout", use_container_width=True):

    st.session_state.logged_in = False
    st.session_state.username = ""
    st.rerun()


# =====================================================
# 8. MAIN DASHBOARD
# =====================================================

st.title("📊 SR University Academic Dashboard")

st.caption(
    "College Timetable Preparation and Academic Management System"
)

st.divider()


# =====================================================
# 9. DASHBOARD HOME
# =====================================================

if menu == "Dashboard":

    st.subheader("Welcome to Academic Management Portal")

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("Total Students", len(students_df))
    c2.metric("Total Faculty", len(faculty_df))
    c3.metric("Total Sections", len(sections))
    c4.metric("Total Classrooms", len(ROOMS))

    st.divider()

    col1, col2 = st.columns(2)

    with col1:

        st.subheader("Department-wise Students")

        department_data = students_df.groupby(
            "Department"
        ).size()

        st.bar_chart(department_data)

    with col2:

        st.subheader("Section-wise Students")

        section_data = students_df.groupby(
            "Section"
        ).size()

        st.bar_chart(section_data)

    st.divider()

    st.subheader("Weekly Timetable Preview")

    st.dataframe(
        timetable_df.head(20),
        use_container_width=True,
        hide_index=True
    )

    if not st.session_state.marks_df.empty:

        st.metric(
            "Average Student Marks",
            f"{st.session_state.marks_df['Marks'].mean():.2f}"
        )


# =====================================================
# 10. STUDENT MANAGEMENT
# =====================================================

elif menu == "Student Management":

    st.subheader("👨‍🎓 Student Management")

    st.metric("Total Students", len(students_df))

    department_options = sorted(
        students_df["Department"].unique().tolist()
    )

    section_options = sorted(
        students_df["Section"].unique().tolist()
    )

    department = st.selectbox(
        "Select Department",
        ["All"] + department_options
    )

    section = st.selectbox(
        "Select Section",
        ["All"] + section_options
    )

    filtered = students_df.copy()

    if department != "All":
        filtered = filtered[
            filtered["Department"] == department
        ]

    if section != "All":
        filtered = filtered[
            filtered["Section"] == section
        ]

    student_display = filtered[
        [
            "Student_Name",
            "Department",
            "Section",
            "Year",
            "Email"
        ]
    ]

    st.dataframe(
        student_display,
        use_container_width=True,
        hide_index=True
    )

    st.download_button(
        "⬇️ Download Student Details",
        student_display.to_csv(index=False).encode("utf-8"),
        "student_details.csv",
        "text/csv"
    )


# =====================================================
# 11. FACULTY MANAGEMENT
# =====================================================

elif menu == "Faculty Management":

    st.subheader("👨‍🏫 Faculty Management")

    st.metric("Total Faculty Members", len(faculty_df))

    departments = sorted(
        faculty_df["Department"].unique().tolist()
    )

    department = st.selectbox(
        "Select Department",
        ["All"] + departments
    )

    filtered = faculty_df.copy()

    if department != "All":
        filtered = filtered[
            filtered["Department"] == department
        ]

    faculty_display = filtered[
        [
            "Faculty_Name",
            "Department",
            "Email"
        ]
    ]

    st.dataframe(
        faculty_display,
        use_container_width=True,
        hide_index=True
    )

    st.download_button(
        "⬇️ Download Faculty Details",
        faculty_display.to_csv(index=False).encode("utf-8"),
        "faculty_details.csv",
        "text/csv"
    )


# =====================================================
# 12. TIMETABLE MANAGEMENT
# =====================================================

elif menu == "Timetable Management":

    st.subheader("📅 Timetable Management")

    day = st.selectbox(
        "Select Day",
        ["All"] + DAYS
    )

    section = st.selectbox(
        "Select Section",
        ["All"] + sections
    )

    filtered = timetable_df.copy()

    if day != "All":
        filtered = filtered[
            filtered["Day"] == day
        ]

    if section != "All":
        filtered = filtered[
            filtered["Section"] == section
        ]

    st.dataframe(
        filtered,
        use_container_width=True,
        hide_index=True
    )

    st.download_button(
        "⬇️ Download Timetable",
        filtered.to_csv(index=False).encode("utf-8"),
        "timetable.csv",
        "text/csv"
    )


# =====================================================
# 13. SECTION MANAGEMENT
# =====================================================

elif menu == "Section Management":

    st.subheader("🏫 Section Management")

    summary = students_df.groupby(
        ["Department", "Section"]
    ).size().reset_index(
        name="Total Students"
    )

    st.dataframe(
        summary,
        use_container_width=True,
        hide_index=True
    )

    st.subheader("Section-wise Strength")

    st.bar_chart(
        students_df.groupby("Section").size()
    )


# =====================================================
# 14. MARKS ALLOCATION
# =====================================================

elif menu == "Marks Allocation":

    st.subheader("📝 Marks Allocation")

    selected_student = st.selectbox(
        "Select Student Name",
        students_df["Student_Name"].tolist()
    )

    student = students_df[
        students_df["Student_Name"] == selected_student
    ].iloc[0]

    st.info(
        f"Student: {student['Student_Name']} | "
        f"Department: {student['Department']} | "
        f"Section: {student['Section']} | "
        f"Year: {student['Year']}"
    )

    with st.form("marks_form"):

        subject = st.selectbox(
            "Select Subject",
            SUBJECTS
        )

        exam = st.selectbox(
            "Select Exam",
            [
                "Internal 1",
                "Internal 2",
                "Mid Examination",
                "Semester Examination"
            ]
        )

        marks = st.number_input(
            "Enter Marks",
            min_value=0,
            max_value=100,
            value=0
        )

        save = st.form_submit_button(
            "Save Marks",
            use_container_width=True
        )

        if save:

            existing = (
                (st.session_state.marks_df["Student_ID"] == student["Student_ID"]) &
                (st.session_state.marks_df["Subject"] == subject) &
                (st.session_state.marks_df["Exam"] == exam)
            )

            if existing.any():

                st.session_state.marks_df.loc[
                    existing, "Marks"
                ] = marks

                st.success("Marks updated successfully!")

            else:

                new_record = pd.DataFrame([{
                    "Student_ID": student["Student_ID"],
                    "Student_Name": student["Student_Name"],
                    "Section": student["Section"],
                    "Subject": subject,
                    "Exam": exam,
                    "Marks": marks
                }])

                st.session_state.marks_df = pd.concat(
                    [
                        st.session_state.marks_df,
                        new_record
                    ],
                    ignore_index=True
                )

                st.success("Marks saved successfully!")

    st.divider()

    st.subheader("Student Marks Records")

    if not st.session_state.marks_df.empty:

        marks_display = st.session_state.marks_df[
            [
                "Student_Name",
                "Section",
                "Subject",
                "Exam",
                "Marks"
            ]
        ]

        st.dataframe(
            marks_display,
            use_container_width=True,
            hide_index=True
        )

        st.download_button(
            "⬇️ Download Marks",
            marks_display.to_csv(index=False).encode("utf-8"),
            "marks_report.csv",
            "text/csv"
        )

    else:
        st.info("No marks have been allocated yet.")


# =====================================================
# 15. ROOM ALLOCATION
# =====================================================

elif menu == "Room Allocation":

    st.subheader("🏢 Room Allocation")

    room_summary = timetable_df.groupby(
        "Room"
    ).agg(
        Total_Classes=("Subject", "count"),
        Total_Sections=("Section", "nunique"),
        Total_Faculty=("Faculty", "nunique")
    ).reset_index()

    st.dataframe(
        room_summary,
        use_container_width=True,
        hide_index=True
    )

    selected_room = st.selectbox(
        "Select Classroom",
        ROOMS
    )

    room_data = timetable_df[
        timetable_df["Room"] == selected_room
    ]

    st.subheader(f"Schedule for {selected_room}")

    st.dataframe(
        room_data,
        use_container_width=True,
        hide_index=True
    )


# =====================================================
# 16. REPORTS AND DOWNLOADS
# =====================================================

elif menu == "Reports & Downloads":

    st.subheader("📥 Reports and Downloads")

    student_report = students_df[
        [
            "Student_Name",
            "Department",
            "Section",
            "Year",
            "Email"
        ]
    ]

    faculty_report = faculty_df[
        [
            "Faculty_Name",
            "Department",
            "Email"
        ]
    ]

    timetable_report = timetable_df.copy()

    marks_report = st.session_state.marks_df[
        [
            "Student_Name",
            "Section",
            "Subject",
            "Exam",
            "Marks"
        ]
    ]

    reports = {
        "Student Details": student_report,
        "Faculty Details": faculty_report,
        "Timetable": timetable_report,
        "Marks Report": marks_report
    }

    for report_name, report_data in reports.items():

        st.subheader(report_name)

        st.dataframe(
            report_data,
            use_container_width=True,
            hide_index=True
        )

        st.download_button(
            f"⬇️ Download {report_name}",
            report_data.to_csv(index=False).encode("utf-8"),
            report_name.lower().replace(" ", "_") + ".csv",
            "text/csv",
            key="download_" + report_name
        )

    st.divider()

    st.subheader("Project Summary")

    summary = pd.DataFrame({
        "Category": [
            "Departments",
            "Students",
            "Faculty Members",
            "Sections",
            "Working Days",
            "Periods Per Day",
            "Classrooms",
            "Timetable Entries"
        ],
        "Count": [
            students_df["Department"].nunique(),
            len(students_df),
            len(faculty_df),
            len(sections),
            len(DAYS),
            6,
            len(ROOMS),
            len(timetable_df)
        ]
    })

    st.dataframe(
        summary,
        use_container_width=True,
        hide_index=True
    )


# =====================================================
# 17. FOOTER
# =====================================================

st.divider()

st.markdown(
    """
    <div style="text-align:center; color:gray;">
        <h3>🎓 SR UNIVERSITY</h3>
        Academic Management Portal<br>
        College Timetable Preparation System<br>
        © 2026
    </div>
    """,
    unsafe_allow_html=True
)
